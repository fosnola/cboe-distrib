//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Char Editor.rc
//
#define IDR_MENU1                       101
#define IDM_FILE_OPEN                   101
#define IDM_FILE_CLOSE                  102
#define IDM_FILE_SAVE                   103
#define IDM_FILE_SAVE_AS                104
#define IDM_FILE_REVERT                 105
#define IDM_FILE_QUIT                   106
#define IDM_PARTY_GOLD                  107
#define IDM_PARTY_FOOD                  108
#define IDM_PARTY_ALCHEMY               109
#define IDM_PARTY_DAMAGE                110
#define IDM_PARTY_MANA                  111
#define IDM_PARTY_DEAD                  112
#define IDM_PARTY_CONDITIONS            113
#define IDM_PARTY_REUNITE               114
#define IDM_PARTY_VEHICLES              115
#define IDM_PARTY_MAGE                  116
#define IDM_PARTY_PRIEST                117
#define IDM_PARTY_TRAITS                118
#define IDM_PARTY_SKILLS                119
#define IDM_PARTY_XP                    120
#define IDM_SCEN_DAY                    121
#define IDM_SCEN_LEAVE_TOWN             122
#define IDM_SCEN_TOWN_RESET             123
#define IDM_SCEN_TOWN_MAP               124
#define IDM_SCEN_OUT_MAP                125
#define IDM_SCEN_LEAVE                  126
#define IDM_SCEN_SDF                    127
#define IDM_HELP                        128
#define IDM_ABOUT                       129
#define IDM_PARTY_ITEM                  130

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40010
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           130
#endif
#endif
