/*

The navbar, to be included in all files.

*/

document.write('\
<a href="About.html"><li>About</li></a>\
<a href="Tips.html"><li>Playing Tips</a></li>\
<a href="Intro.html"><li>Getting Started</li></a>\
<a href="Screen.html"><li>The Exile Screen</a></li>\
<a href="Menus.html"><li>The Exile Menu</a></li>\
<a href="Town.html"><li>Getting Around Town</a></li>\
<a href="Outdoors.html"><li>Getting Around the Outdoors</a></li>\
<a href="Combat.html"><li>Killing Stuff</a></li>\
<a href="Misc.html"><li>Miscellaneous</li></a>\
<a href="Mage.html"><li>Mage Spells</a></li>\
<a href="Priest.html"><li>Priest Spells</a></li>\
<a href="Hints.html"><li>Hints</a></li>\
<a href="Valleydy.html"><li>Valley of Dying Things</a></li>\
<a href="Editor.html"><li>The Editor</a></li>\
<a href="Credits.html"><li>Credits</a></li>\
<a href="Licensing.html"><li>GNU GPL</a></li>\
');