//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Blades of Exile.rc
//
#define IDI_BLADESOFEXILE               107
#define IDC_BLADESOFEXILE               109
#define IDM_FILE_OPEN                   110
#define IDM_FILE_SAVE                   111
#define IDM_FILE_SAVE_AS                112
#define IDM_FILE_NEW                    113
#define IDM_FILE_PREFS                  114
#define IDM_FILE_QUIT                   115
#define IDM_OPTIONS_GRAPHIC             116
#define IDM_OPTIONS_NAME                117
#define IDM_OPTIONS_NEW                 118
#define IDM_OPTIONS_DELETE              119
#define IDM_OPTIONS_TALKING             120
#define IDM_OPTIONS_ENCOUNTER           121
#define IDM_OPTIONS_STATS               122
#define IDM_ACTIONS_ALCHEMY             123
#define IDM_ACTIONS_WAIT                124
#define IDM_ACTIONS_MAP                 125
#define IDM_MONSTERS_ABOUT              126
#define IDM_MAGE_ABOUT                  127
#define IDM_PRIEST_ABOUT                128
#define IDM_FILE_ABORT                  129
#define IDM_LIBRARY_MAGE                130
#define IDM_LIBRARY_PRIEST              131
#define IDM_LIBRARY_SKILLS              132
#define IDM_LIBRARY_ALCHEMY             133
#define IDM_LIBRARY_TIPS                134
#define IDM_LIBRARY_INTRO               135
#define IDM_HELP_INDEX                  136
#define IDM_HELP_OUTDOOR                137
#define IDM_HELP_COMBAT                 138
#define IDM_HELP_BARRIER                139
#define IDM_HELP_HINTS                  140
#define IDM_HELP_SPELLS                 141
#define IDM_HELP_ABOUT                  142
#define IDM_HELP_TOWN                   143
#define IDM_OPTIONS_JOURNAL             144
#define IDI_BOESAVE                     145
#define IDI_BOESCEN                     146

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           147
#endif
#endif
