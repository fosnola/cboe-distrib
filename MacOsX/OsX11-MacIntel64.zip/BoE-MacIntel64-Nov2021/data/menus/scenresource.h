//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Scen Editor.rc
//
#define IDR_MENU1                       101
#define IDM_FILE_NEW                    101
#define IDM_FILE_OPEN                   102
#define IDM_FILE_CLOSE                  103
#define IDM_FILE_SAVE                   104
#define IDM_FILE_REVERT                 105
#define IDM_FILE_QUIT                   106
#define IDM_SCEN_NEW_TOWN               107
#define IDM_SCEN_DETAILS                108
#define IDM_SCEN_START                  109
#define IDM_SCEN_ADV_SPECIALS           110
#define IDM_SCEN_ADV_TEXT               111
#define IDM_SCEN_ADV_JOURNAL            112
#define IDM_SCEN_ADV_IMPORT_TOWN        113
#define IDM_SCEN_ADV_SAVE_RECTS         114
#define IDM_SCEN_ADV_HORSES             115
#define IDM_SCEN_ADV_BOATS              116
#define IDM_SCEN_ADV_TOWN_VARY          117
#define IDM_SCEN_ADV_EVENTS             118
#define IDM_SCEN_ADV_SHORTCUTS          119
#define IDM_SCEN_ADV_DELETE_TOWN        120
#define IDM_SCEN_ADV_DATA_DUMP          121
#define IDM_SCEN_ADV_TEXT_DUMP          122
#define IDM_SCEN_INTRO                  123
#define IDM_SCEN_PASSWORD               124
#define IDM_TOWN_DETAILS                125
#define IDM_TOWN_WANDER                 126
#define IDM_TOWN_BOUNDS                 127
#define IDM_TOWN_FRILL                  128
#define IDM_TOWN_UNFRILL                129
#define IDM_TOWN_AREAS                  130
#define IDM_TOWN_RANDOM_ITEMS           131
#define IDM_TOWN_NOT_PROPERTY           132
#define IDM_TOWN_CLEAR_ITEMS            133
#define IDM_TOWN_ADV_SPECIALS           134
#define IDM_TOWN_ADV_TEXT               135
#define IDM_TOWN_ADV_SIGNS              136
#define IDM_TOWN_ADV_DETAILS            137
#define IDM_TOWN_ADV_EVENTS             138
#define IDM_TOWN_ADV_REPORT             139
#define IDM_OUT_DETAILS                 140
#define IDM_OUT_WANDER                  141
#define IDM_OUT_ENCOUNTER               142
#define IDM_OUT_FRILL                   143
#define IDM_OUT_UNFRILL                 144
#define IDM_OUT_AREAS                   145
#define IDM_OUT_START                   146
#define IDM_OUT_ADV_SPECIALS            147
#define IDM_OUT_ADV_TEXT                148
#define IDM_OUT_ADV_SIGNS               149
#define IDM_OUT_ADV_REPORT              150
#define IDM_HELP_INDEX                  151
#define IDM_HELP_ABOUT                  152
#define IDM_HELP_START                  153
#define IDM_HELP_TEST                   154
#define IDM_HELP_DISTRIBUTE             155
#define IDM_EDIT_UNDO                   156
#define IDM_EDIT_REDO                   157
#define IDM_EDIT_CUT                    158
#define IDM_EDIT_COPY                   159
#define IDM_EDIT_PASTE                  160
#define IDM_EDIT_DELETE                 161
#define IDM_EDIT_SELECT                 162
#define IDM_SCEN_CUSTOM_PICS            163
#define IDM_SCEN_CUSTOM_SHEETS          164
#define IDM_SCEN_CUSTOM_SNDS            165
#define IDM_FILE_SAVE_AS                166
#define IDM_SCEN_RESIZE_OUTDOORS        167
#define IDM_SCEN_ADV_IMPORT_OUT         168
#define IDM_GRAYED_LABEL                169

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40014
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           170
#endif
#endif
